package com.example.project.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class exampleprojectcontroller {
	@GetMapping("/signuppage")
	public String signuppage()
	{
		return "welcome to signup page";
	}
	@GetMapping("/homepage/{userid}")
	public String homepage(@PathVariable("userid") String userid)
	{
		return "welcome to signup page "+userid;
	}

}